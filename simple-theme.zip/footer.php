		<footer class="container-fluid">
			<?php wp_footer(); ?>
			<div class="col-md-4 col-xs-12 text-center footer-block sidebar">
				<?php dynamic_sidebar('footer-1') ?>
			</div>
			<div class="col-md-4 col-xs-12 text-center footer-block sidebar">
				<?php dynamic_sidebar('footer-2') ?>
			</div>
			<div class="col-md-4 col-xs-12 text-center footer-block sidebar">
				<?php dynamic_sidebar('footer-3') ?>
			</div>
		</footer>
	</body>
</html>
