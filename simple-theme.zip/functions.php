<?php
function simple_setup () {
	add_theme_support('post-thumbnails');

	register_nav_menu('main-menu', 'Main menu on the header');

	register_sidebar(array(
		'name' => 'Sidebar',
		'id' => 'sidebar',
		'description' => 'Sidebar on the right side',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => "</div>",
		'before_title' => '<h3 class="widgettitle">',
		'after_title' => "</h3>"
	));

	register_sidebar(array(
		'name' => 'Footer 1',
		'id' => 'footer-1',
		'description' => 'Footer block 1',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => "</div>",
		'before_title' => '<h3 class="widgettitle">',
		'after_title' => "</h3>"
	));

	register_sidebar(array(
		'name' => 'Footer 2',
		'id' => 'footer-2',
		'description' => 'Footer block 2',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => "</div>",
		'before_title' => '<h3 class="widgettitle">',
		'after_title' => "</h3>"
	));

	register_sidebar(array(
		'name' => 'Footer 3',
		'id' => 'footer-3',
		'description' => 'Footer block 3',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget' => "</div>",
		'before_title' => '<h2 class="widgettitle">',
		'after_title' => "</h2>"
	));
}

add_action('init', 'simple_setup');

function simple_add_scripts () {
	wp_enqueue_style('bootstrap-css', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css');
	wp_enqueue_style('main-css', get_stylesheet_uri());
	wp_enqueue_style('flickity-css', get_stylesheet_directory_uri() . '/css/vendor/flickity.css');
	wp_enqueue_script('flickity-js', get_stylesheet_directory_uri() . '/js/vendor/flickity.pkgd.min.js');
	wp_enqueue_script('main-js', get_stylesheet_directory_uri() . '/js/main.js', array('jquery'));
	wp_enqueue_script('navs-js', get_stylesheet_directory_uri() . '/js/navs.js', array('jquery'));
	wp_enqueue_style('fonts', '//fonts.googleapis.com/css?family=Roboto:400,900');
	wp_enqueue_style('icon-font', 'https://file.myfontastic.com/QycLBibxNQkxgfK7R6naAA/icons.css');
}

add_action('wp_enqueue_scripts', 'simple_add_scripts');

function simple_customize_register ($wp_customize) {
	$wp_customize->add_section('layout', array(
		'title' => 'Theme Layout'
	));

	$wp_customize->add_setting('featured_posts', array(
		'default' => true,
		'transport' => 'refresh'
	));

	$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'featured_posts', array(
			'label' => 'Show Featured Posts',
			'section' => 'layout',
			'settings' => 'featured_posts',
			'type' => 'checkbox'
		)
	));

	$wp_customize->add_section('colors', array(
		'title' => 'Theme Colors',
		'priority' => 30
	));

	$wp_customize->add_setting('main_color', array(
		'default' => '#f44336',
		'transport' => 'refresh'
	));

	$wp_customize->add_setting('accent_color', array(
		'default' => '#607d8b',
		'transport' => 'refresh'
	));

	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'main_color', array(
			'label' => 'Main Color',
			'section' => 'colors',
			'settings' => 'main_color'
		)
	));

	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'accent_color', array(
			'label' => 'Accent Color',
			'section' => 'colors',
			'settings' => 'accent_color'
		)
	));
}

add_action('customize_register', 'simple_customize_register');

function simple_customize_css () {
	$main_color = get_theme_mod('main_color');
	$accent_color = get_theme_mod('accent_color');
	?>
		<style media="screen">
			a {
				color: <?= $main_color ?>
			}

			a:hover {
				color: <?= $main_color ?>;
			}

			.btn-primary {
				background-color: <?= $main_color ?>;
			}

			.btn-primary:hover {
				background-color: <?= $main_color ?>;
				box-shadow: 0 0 30px rgba(0, 0, 0, 0.75) inset;
			}

			.featured-posts .featured-post {
				background-color: <?= $accent_color ?>;
			}
		</style>
	<?php
}

add_action('wp_head', 'simple_customize_css');

?>
