<?php get_header(); ?>
<div class="main-wrapper">
	<?php
		if (get_theme_mod('featured_posts')) {
			require_once('inc/components/featured-posts.php');
		}
	?>
	<div class="container content-wrapper">
		<div class="posts-container col-md-8 col-xs-12">
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<!-- post -->
				<div <?php post_class() ?>>
					<?php if (has_post_thumbnail()) : ?>
						<div class="post-thumbnail col-xs-12">
							<img src="<?php the_post_thumbnail_url(); ?>" class="img-responsive" alt="" />
						</div>
					<?php endif; ?>
					<div class="col-xs-12">
						<h2><?php the_title() ?></h2>
						<?php the_excerpt() ?>
						<a class="btn btn-primary" href="<?php the_permalink(); ?>">Read More</a>
					</div>
				</div>
			<?php endwhile; ?>
				<!-- post navigation -->
			<?php else: ?>
				<!-- no posts found -->
			<?php endif; ?>
		</div>
		<div id="main-sidebar" class="sidebar sidebar-container col-md-4 col-xs-12">
			<?php dynamic_sidebar('sidebar') ?>
		</div>
	</div>
</div>
<?php get_footer(); ?>
